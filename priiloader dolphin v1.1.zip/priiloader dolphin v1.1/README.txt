place the file in the (loader) folder in the sameplace
that you have all youre wii/gamecube roms


place the apps folder on the digital sd card
you can also use openshop/libreshop to get the priiloader installer
then use the homebrew menu to install priiloader 
(bind the + button to any key and press it on the installer screen)